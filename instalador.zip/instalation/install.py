""" Instalação do python e dependências para rodar o projeto"""

import json
import os
import sys
import pip
import subprocess

class Install:
    def __init__(self):
        self.pasta_instalation = os.path.dirname(os.path.abspath(__file__))
        self.raiz_projeto = os.path.dirname(self.pasta_instalation)
        self.arquivo_dependencias = os.path.join(self.pasta_instalation, "dependencies.json")
        with open(self.arquivo_dependencias, "r") as f:
            data = json.load(f)
        self.python_version = data["py_version"]
        self.pip_version = data["pip_version"]
        self.libs = data["libs"]

    def criar_atalho(self):
        # Cria um atalho para o script principal.
        # app.py sempre fica em componentes/, tanto no repositório quanto no
        # pacote instalado — nunca precisa ser movido de lugar.
        if os.name == "nt":  # Windows
            atalho = os.path.join(os.path.expanduser("~"), "Desktop", "AssistentePlanilhasIA.lnk")
            pasta_componentes = os.path.join(self.raiz_projeto, "componentes")
            target = os.path.join(pasta_componentes, "app.py")
            icon = os.path.join(self.pasta_instalation, "icon.ico")
            if not os.path.exists(target):
                print(f"app.py não encontrado em {target}. Atalho não foi criado.")
                return
            try:
                import pythoncom
                from win32com.shell import shell, shellcon

                shell_link = pythoncom.CoCreateInstance(
                    shell.CLSID_ShellLink, None, pythoncom.CLSCTX_INPROC_SERVER, shell.IID_IShellLink
                )
                # streamlit precisa ser aberto via "python -m streamlit run",
                # nunca "python app.py" direto (o script roda sem servidor).
                shell_link.SetPath(sys.executable)
                shell_link.SetArguments(f'-m streamlit run "{target}"')
                shell_link.SetWorkingDirectory(pasta_componentes)
                shell_link.SetIconLocation(icon, 0)
                persist_file = shell_link.QueryInterface(pythoncom.IID_IPersistFile)
                persist_file.Save(atalho, 0)
                print(f"Atalho criado na área de trabalho: {atalho}")
            except ImportError:
                print("Biblioteca pywin32 não encontrada. Não foi possível criar o atalho.")
        else:
            print("Criação de atalho não suportada neste sistema operacional.")
        

    def instalar_dependencias(self):
        self._verificar_pip()

        # Verfica se as dependências estão instaladas
        for dependencias in self.libs:
            try:
                __import__(dependencias.split("==")[0])
            except ImportError:
                print(f"Dependência {dependencias} não encontrada. Instalando...")
                try:
                    subprocess.check_call([sys.executable, "-m", "pip", "install", dependencias])
                    print(f"Dependência {dependencias} instalada com sucesso!")
                except subprocess.CalledProcessError as erro:
                    print(f"Erro ao instalar a dependência {dependencias}: {erro} \n")
                    print("""
####################################################
    Tente instalar manualmente com o comando:
            pip install {dependencias}
####################################################
                    """)    

    def _verificar_pip(self):
        # Verifica se o pip está instalado
        try:
            if pip.__version__:
                print(f"Pip Instalado: {pip.__version__}")
        except ImportError:
            print("Pip não Encontrado. Tentando ativa-lo...")

            try:
                subprocess.check_call([sys.executable, "-m", "ensurepip", "--default-pip"])
            except subprocess.CalledProcessError as erro:
                print(f"Erro ao ativar o pip: {erro}\nTentando instalar o pip manualmente...")

                # Baixa o get-pip.py real (o link anterior baixava a home da pypa.io,
                # não o script, e o pip nunca era de fato instalado)
                import urllib.request
                try:
                    url = "https://bootstrap.pypa.io/get-pip.py"
                    urllib.request.urlretrieve(url, "get-pip.py")
                    subprocess.check_call([sys.executable, "get-pip.py"])
                    print("Pip instalado manualmente com sucesso!")
                except Exception as e:
                    print(f"Falha crítica ao instalar o pip: {e}")


if __name__ == "__main__":
    instalador = Install()
    instalador.instalar_dependencias()
    instalador.criar_atalho()
    print("\nInstalação concluída.")
