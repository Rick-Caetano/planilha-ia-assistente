@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"

set "NOME=AssistentePlanilhasIA"
set "DIST=dist\%NOME%"

echo Montando pacote de distribuicao em %DIST%...

if exist "dist" rmdir /s /q "dist"
mkdir "%DIST%"
mkdir "%DIST%\instalation"

rem Instalador (raiz do pacote) + logica de dependencias
copy "Instalar.bat" "%DIST%\Instalar.bat" >nul
copy "requirements.txt" "%DIST%\requirements.txt" >nul
copy "instalation\install.py" "%DIST%\instalation\install.py" >nul
copy "instalation\dependencies.json" "%DIST%\instalation\dependencies.json" >nul
copy "instalation\icon.ico" "%DIST%\instalation\icon.ico" >nul

rem Codigo-fonte do app: sempre em componentes/, igual ao repositorio
robocopy "componentes" "%DIST%\componentes" /E /XD __pycache__ .git >nul

echo Compactando %NOME%.zip...
powershell -NoProfile -Command "Compress-Archive -Path '%DIST%\*' -DestinationPath 'dist\%NOME%.zip' -Force"

echo.
echo Pronto: dist\%NOME%.zip
echo Esse e o arquivo pra anexar numa Release do GitHub.
pause
